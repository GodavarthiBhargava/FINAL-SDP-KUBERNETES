import React from 'react'

function FundTracking() {
  return (
    <div>
      <h1 align="center"> Fund Tracking </h1>
    </div>
  )
}

export default FundTracking

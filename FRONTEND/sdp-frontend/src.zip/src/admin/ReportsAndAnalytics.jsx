import React from 'react'

function ReportsAndAnalytics() {
  return (
	<div>
	  <h1 align="center">Reports and Analytics</h1>
	</div>
  )
}

export default ReportsAndAnalytics
